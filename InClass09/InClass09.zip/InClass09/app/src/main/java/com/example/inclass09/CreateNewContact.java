package com.example.inclass09;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.UUID;

public class CreateNewContact extends AppCompatActivity {

    static final int REQUEST_IMAGE_CAPTURE = 1;
    private ImageView photo;
    private Button btnSubmit;
    private TextView textViewName;
    private TextView textViewEmail;
    private TextView textViewPhone;
    private Bitmap imageBitmap;

    DatabaseReference myRootRef = FirebaseDatabase.getInstance().getReference();
    DatabaseReference myRef = myRootRef.child("contacts");
    ArrayList<Contact> contactLst;
    FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        firebaseAuth = FirebaseAuth.getInstance();
        contactLst = new ArrayList<Contact>();
        final String id = UUID.randomUUID().toString();

        photo = findViewById(R.id.imageView_ContactPhoto);
        btnSubmit = findViewById(R.id.button_Submit);
        textViewName = findViewById(R.id.editText_Name);
        textViewEmail = findViewById(R.id.editText_Email);
        textViewPhone = findViewById(R.id.editText_PhNum);

        photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("Demo", "ImageClick");
                /*Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
                startActivity(intent);*/
                Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
                    startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
                }
            }
        });

        btnSubmit.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                String contactName = textViewName.getText().toString();
                String email = textViewEmail.getText().toString();
                String phoneNum = textViewPhone.getText().toString();

                if(contactName.length() < 1){
                    textViewName.setError("Please Enter Name");
                }else if(email.length() < 1){
                    textViewEmail.setError("Please Enter Email");
                }else if(phoneNum.length() < 1){
                    textViewPhone.setError("Please Enter Phone Number");
                }else{
                    Log.d("Demo", "Name" + contactName);
                    Log.d("Demo", "Email" + email);
                    Log.d("Demo", "PhNum" + phoneNum);
                    if(imageBitmap != null){
                        Log.d("Demo", "You Have Image");
                    }


                    final Contact contact = new Contact(textViewName.getText().toString(), textViewEmail.getText().toString(), textViewPhone.getText().toString(), imageBitmap);
                    Log.d("demo: ",contact.toString());
                    writeNewContact(firebaseAuth.getUid(), textViewName.getText().toString(), textViewEmail.getText().toString(), textViewPhone.getText().toString(), imageBitmap, id);

                    myRootRef.child("contacts").child(firebaseAuth.getCurrentUser().getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {

                            Log.d("Demo", "HEYYY");

                            for (DataSnapshot ds: dataSnapshot.getChildren()) {
                                Contact contact = new Contact();
                                contact.setName(ds.child("name").getValue(String.class));
                                contact.setPhone(ds.child("phone").getValue(String.class));

                                //int image = ds.child("imageResId").getValue(Integer.class);
                                //contact.setImageBitmap(imageBitmap);

                                contact.setEmail(ds.child("email").getValue(String.class));
                                contactLst.add(contact);
                            }
                            Intent intent = new Intent();
                            intent.putExtra(ContactListAct.VALUE_KEY, contactLst);
                            startActivity(new Intent(CreateNewContact.this, ContactListAct.class));
                            finish();
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {

                        }
                    });
                }
            }
        });
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Log.d("Demo", "onActivity result");
            Bundle extras = data.getExtras();
            imageBitmap = (Bitmap) extras.get("data");
            photo.setImageBitmap(imageBitmap);
        }
    }

    private void writeNewContact(String userId, String name, String email, String phone, Bitmap imgBitMap, String id) {
        Contact contact = new Contact(name, email, phone, imgBitMap);
        myRef.child(userId).child(id).setValue(contact);
    }
}
